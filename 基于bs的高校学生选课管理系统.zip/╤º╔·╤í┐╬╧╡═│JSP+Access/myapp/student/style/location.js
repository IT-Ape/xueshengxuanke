function setLocation()
{
var width= window.screen.width;
var mid=width/2;
var x=mid-110;
//window.alert(x);
document.getElementById("login").style.visibility='visible';
document.getElementById("login").style.left=x+"px";
}