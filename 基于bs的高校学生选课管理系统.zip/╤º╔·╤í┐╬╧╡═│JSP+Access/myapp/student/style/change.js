// JavaScript Document
function change1()
{
	document.getElementById("spann").style.background="url(style/menu_back.png)";
	document.getElementById("spann").style.background-repeat="repeat";
}